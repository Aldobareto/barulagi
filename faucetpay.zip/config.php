<?
/// Setiap login ke web maka confignya berubah.
/// jangan sering login klo mau confignya awet tanpa capture ulang

$UserAgent = "xxxxxxxx";
$FaucetPay = "xxxxxxxx";
$SessionToken = "xxxxxxxxx";
$VisitorUnique = "xxxxxxxxx";
$RememberMe = "xxxxxxxxx";